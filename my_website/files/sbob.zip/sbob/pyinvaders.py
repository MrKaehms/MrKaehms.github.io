from pygame import *
import random


class Sprite:
	def __init__(self, xpos, ypos, filename):
		self.x = xpos
		self.y = ypos
		self.bitmap = image.load(filename)
		self.bitmap.set_colorkey((0,0,0))
	def set_position(self, xpos, ypos):
		self.x = xpos
		self.y = ypos
	def render(self):
		screen.blit(self.bitmap, (self.x, self.y))

class Gold(Sprite):
	def __init__(self, xpos, ypos):
		self.x = xpos
		self.y = ypos
		self.bitmap = image.load('data/images/pirategold.png')
		self.drops=0;
	def render(self):
		screen.blit(self.bitmap, (self.x, self.y))
	def drop():
		self.y = self.y + 10	
				
def Intersect(s1_x, s1_y, s2_x, s2_y):
	if (s1_x > s2_x - 32) and (s1_x < s2_x + 32) and (s1_y > s2_y - 32) and (s1_y < s2_y + 32):
		return 1
	else:
		return 0


init()
# orig: screen = display.set_mode((640,480))
screen = display.set_mode((800,600))
key.set_repeat(1, 1)
display.set_caption('PyInvaders')
# orig: backdrop = image.load('data/backdrop.bmp')
backdrop = image.load('data/images/underwater-background.jpg')

enemies = []

x = 0

''' ORIG - get rid of enemies!
for count in range(10):
# orig: 	enemies.append(Sprite(50 * x + 50, 50, 'data/baddie.bmp'))
	enemies.append(Sprite(50 * x + 50, 50, 'data/images/crabtrap.png')) 
	x += 1
'''
hero = Sprite(20, 400, 'data/hero.bmp')
# updatehero = Sprite(400, 500, 'data/images/sbob.png')
hero = Sprite(20, 500, 'data/images/sbob.png')
ourmissile = Sprite(0, 480, 'data/heromissile.bmp')
enemymissile = Sprite(0, 480, 'data/baddiemissile.bmp')
gold=Gold(400,10)


quit = 0
# orig: enemyspeed = 3

while quit == 0:
	screen.blit(backdrop, (0, 0))
    
	gold.render()
	gold.drop

	''' ORIG - get rid of enemies!
	for count in range(len(enemies)):
		enemies[count].x += + enemyspeed
		enemies[count].render()

	if enemies[len(enemies)-1].x > 590:
		enemyspeed = -3
		for count in range(len(enemies)):
			enemies[count].y += 5

	if enemies[0].x < 10:
		enemyspeed = 3
		for count in range(len(enemies)):
			enemies[count].y += 5
	'''
	if ourmissile.y < 479 and ourmissile.y > 0:
		ourmissile.render()
		ourmissile.y -= 5

	if enemymissile.y >= 480 and len(enemies) > 0:
		enemymissile.x = enemies[random.randint(0, len(enemies) - 1)].x
		enemymissile.y = enemies[0].y

	if gold.y < 500:
		gold.y +=2
    	
	if Intersect(hero.x, hero.y, enemymissile.x, enemymissile.y):
		quit = 1

	''' ORIG - get rid of enemies!
	for count in range(0, len(enemies)):
		if Intersect(ourmissile.x, ourmissile.y, enemies[count].x, enemies[count].y):
			del enemies[count]
			break

	if len(enemies) == 0:
		quit = 1
	'''
	for ourevent in event.get():
		if ourevent.type == QUIT:
			quit = 1
		if ourevent.type == KEYDOWN:
			if ourevent.key == K_RIGHT and hero.x < 590:
				hero.x += 5
			if ourevent.key == K_LEFT and hero.x > 10:
				hero.x -= 5
			if ourevent.key == K_SPACE:
				ourmissile.x = hero.x
				ourmissile.y = hero.y


	enemymissile.render()
	enemymissile.y += 5

	hero.render()

	display.update()
	time.delay(5)

